/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

/**
 *
 * @author MI PC
 */
import java.util.*;
public class LoginRegistro {
    //estructura de datos en pila LIFO
    //se usa stack para registrar accesos exitosos
  private Stack<String> exitosos = new Stack<>();
  
  //estructura de datos en cola FIFO
  //se usa queue para almacenar accesos fallidos 
    private Queue<String> fallidos = new LinkedList<>();

    public void registrarExito(String email) {
        exitosos.push(email);
    }

    public void registrarFallo(String email) {
        fallidos.offer(email);
    }

    public void mostrarLogs() {
        System.out.println("Éxitos:");
        for (String e : exitosos) System.out.println(e);

        System.out.println("Fallidos:");
        for (String f : fallidos) System.out.println(f);
    }  
}
