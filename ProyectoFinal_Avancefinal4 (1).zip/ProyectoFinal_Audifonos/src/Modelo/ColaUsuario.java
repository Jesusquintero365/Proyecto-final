/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author MI PC
 */
public class ColaUsuario {
     private NodoUsuario frente;
    private NodoUsuario fin;

    public ColaUsuario() {
        this.frente = null;
        this.fin = null;
    }

    public void encolar(Usuario usuario) {
        NodoUsuario nuevo = new NodoUsuario(usuario);
        if (estaVacia()) {
            frente = fin = nuevo;
        } else {
            fin.setSiguiente(nuevo);
            fin = nuevo;
        }
    }

    public Usuario desencolar() {
        if (estaVacia()) {
            return null;
        }
        Usuario dato = frente.getDato();
        frente = frente.getSiguiente();
        if (frente == null) {
            fin = null;
        }
        return dato;
    }

    public boolean estaVacia() {
        return frente == null;

}
}